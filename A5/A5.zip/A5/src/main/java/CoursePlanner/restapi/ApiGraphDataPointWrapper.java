package CoursePlanner.restapi;

public class ApiGraphDataPointWrapper {
    public long semesterCode;
    public long totalCoursesTaken;
}