package CoursePlanner.restapi;

public class ApiCourseWrapper {
    public long courseId;
    public String catalogNumber;
}