package CoursePlanner.restapi;

public class ApiDepartmentWrapper {
    public long deptId;
    public String name;
}